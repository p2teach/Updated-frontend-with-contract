const hre = require("hardhat");

async function main() {
  console.log("Deploying P2Teach contract...");
  
  const P2Teach = await hre.ethers.getContractFactory("P2Teach");
  const p2Teach = await P2Teach.deploy();

  console.log("Waiting for deployment...");
  await p2Teach.waitForDeployment();

  const address = await p2Teach.getAddress();
  console.log("P2Teach deployed to:", address);
  
  // Wait for a few block confirmations
  console.log("Waiting for block confirmations...");
  await p2Teach.deploymentTransaction().wait(5);
  
  console.log("Deployment completed!");
  console.log("Contract address:", address);
}

main()
  .then(() => process.exit(0))
  .catch((error) => {
    console.error(error);
    process.exit(1);
  });