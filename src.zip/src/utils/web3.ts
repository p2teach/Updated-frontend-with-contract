import { ethers } from 'ethers';
import P2TeachABI from '../../artifacts/contracts/P2Teach.sol/P2Teach.json';

const CONTRACT_ADDRESS = process.env.VITE_CONTRACT_ADDRESS || '';

export const connectWallet = async () => {
  try {
    if (!window.ethereum) {
      throw new Error('Please install MetaMask or another Web3 wallet');
    }

    const provider = new ethers.BrowserProvider(window.ethereum);
    await provider.send("eth_requestAccounts", []);
    const signer = await provider.getSigner();
    return { provider, signer };
  } catch (error) {
    console.error('Error connecting wallet:', error);
    throw error;
  }
};

export const getContract = async () => {
  const { signer } = await connectWallet();
  return new ethers.Contract(CONTRACT_ADDRESS, P2TeachABI.abi, signer);
};

export const registerUser = async (name: string, email: string) => {
  try {
    const contract = await getContract();
    const tx = await contract.registerUser(name, email);
    await tx.wait();
    return tx;
  } catch (error) {
    console.error('Error registering user:', error);
    throw error;
  }
};

export const updateUser = async (name: string, email: string) => {
  try {
    const contract = await getContract();
    const tx = await contract.updateUser(name, email);
    await tx.wait();
    return tx;
  } catch (error) {
    console.error('Error updating user:', error);
    throw error;
  }
};

export const getUser = async (address: string) => {
  try {
    const contract = await getContract();
    return await contract.getUser(address);
  } catch (error) {
    console.error('Error getting user:', error);
    throw error;
  }
};

export const getTotalUsers = async () => {
  try {
    const contract = await getContract();
    return await contract.getTotalUsers();
  } catch (error) {
    console.error('Error getting total users:', error);
    throw error;
  }
};