
const Bookings = () => {
  return (
    <div>Bookings</div>
  )
}

export default Bookings