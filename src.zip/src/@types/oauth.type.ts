export interface TValidationError  {
    email: string,
    password: string
}