// src/routes/index.tsx (Main router configuration)
import { createBrowserRouter } from "react-router-dom";
import AuthLayout from "../layouts/AuthLayout";
// import PublicRoute from "../components/auth/publicRoute";
import AppLayout from "../layouts/AppLayouts";
// import authRoutes from "./auhtRoute";
import protectedRoutes from "./protectedRoutes";
import loginRoute from "./auth/login";
import registerRoute from "./auth/register";
import SecuredRoute from "../components/auth/securedRoutes";
import PublicRoute from "../components/auth/publicRoute";
import { connectWallet, registerUser, getUser } from '../utils/web3';

// const ProfilePage = lazy(() => import("../pages/App/Profile"));
// const ErrorPage = lazy(() => import("../pages/Error"));

const router = createBrowserRouter([
	{
		path: "/",
		element: <span>Hello world</span>,
	},
	{
		path: "/login/*",
		element: (
			<PublicRoute>
				<AuthLayout />
			</PublicRoute>
		),
		children: loginRoute,
	},
	{
		path: "/register/*",
		element: (
			<PublicRoute>
				<AuthLayout />
			</PublicRoute>
		),
		children: registerRoute,
	},
	{
		path: "/home/*",
		element: (
			<SecuredRoute>
				<AppLayout />
			</SecuredRoute>
		),
		children: protectedRoutes,
	},
]);

// Connect wallet
const handleConnect = async () => {
	try {
		const { provider, signer } = await connectWallet();
		const address = await signer.getAddress();
		console.log('Connected wallet:', address);
	} catch (error) {
		console.error('Failed to connect wallet:', error);
	}
};

// Register user
const handleRegister = async (name: string, email: string) => {
	try {
		const tx = await registerUser(name, email);
		console.log('Registration successful:', tx);
	} catch (error) {
		console.error('Registration failed:', error);
	}
};

// Get user data
const handleGetUser = async (address: string) => {
	try {
		const userData = await getUser(address);
		console.log('User data:', userData);
	} catch (error) {
		console.error('Failed to get user data:', error);
	}
};

export default router;
